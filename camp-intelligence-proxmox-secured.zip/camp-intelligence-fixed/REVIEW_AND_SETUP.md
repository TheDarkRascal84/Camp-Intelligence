# Camp Intelligence — Code Review & Proxmox Setup Guide

---

## 1. Project Overview

**Camp Intelligence** is a full-stack campsite availability platform built with:

- **Frontend:** React 19, Vite, Tailwind CSS v4, TanStack Query, tRPC, Wouter
- **Backend:** Node.js, Express, tRPC, Drizzle ORM, MySQL 8
- **Intelligence Layer:** ML-style prediction models for cancellation probability, booking urgency, demand heatmaps, and price trends
- **Background Jobs:** BullMQ + Redis for async prediction workers
- **Auth:** JWT session tokens, Manus OAuth (adapter present)

---

## 2. Security Fixes Applied

### 🔴 Critical

#### 2.1 Hard exit on missing JWT_SECRET
**File:** `server/_core/env.ts`
Server now calls `process.exit(1)` if `JWT_SECRET` is missing or shorter than 32 characters. Also exits if `DATABASE_URL` is not set.

#### 2.2 HTTP Security Headers (Helmet)
**File:** `server/_core/index.ts`
Added `helmet` middleware. Sets `X-Frame-Options`, `X-Content-Type-Options`, `Strict-Transport-Security`, `Content-Security-Policy`, and other OWASP-recommended headers on every response.

#### 2.3 CORS Policy
**File:** `server/_core/index.ts`
Added `cors` middleware. Configured via `ALLOWED_ORIGINS` env var (comma-separated list). In production with no `ALLOWED_ORIGINS` set, cross-origin requests are blocked entirely.

#### 2.4 Rate Limiting
**File:** `server/_core/index.ts`
Added `express-rate-limit`:
- All `/api/` routes: 200 requests per 15 minutes per IP
- `/api/oauth/` routes: 20 requests per 15 minutes per IP (brute-force protection)

#### 2.5 Request Body Size Reduced
**File:** `server/_core/index.ts`
Reduced from 50MB to 1MB. Closes denial-of-service vector via oversized JSON payloads.

#### 2.6 Port Scan Removed
**File:** `server/_core/index.ts`
Removed the loop that scanned ports 3000–3019. Server now binds to `PORT` exactly and calls `process.exit(1)` if the port is in use. Prevents silent container misconfiguration.

#### 2.7 Open Redirect Fixed in OAuth State
**File:** `server/_core/sdk.ts`
`decodeState()` now validates that the decoded redirect URI is a relative path. Any absolute URL (http/https) is blocked and replaced with `/`.

#### 2.8 No Hardcoded Fallback Secrets in docker-compose
**File:** `docker-compose.yml`
Removed `:-camppass`, `:-rootpass`, etc. Docker Compose will fail loudly if `MYSQL_PASSWORD`, `MYSQL_ROOT_PASSWORD`, or `REDIS_PASSWORD` are not set.

#### 2.9 Redis Password Required
**File:** `docker-compose.yml`
Redis now starts with `--requirepass ${REDIS_PASSWORD}`. The app's `REDIS_URL` and health check use the password. Added `REDIS_PASSWORD` to `.env.example`.

---

### 🟡 Medium

#### 2.10 axios Replaced with Native fetch
**File:** `server/_core/sdk.ts`
Removed `axios` entirely from the OAuth HTTP client. All server-side HTTP now uses Node.js native `fetch` with a 10-second `AbortSignal.timeout`. `axios` and `@types/jsonwebtoken` removed from `package.json`.

#### 2.11 `as any` DB Insert Fixed
**File:** `server/routers.ts`
`db.insert(savedSearches).values(...)` now uses a properly typed `InsertSavedSearch` variable. The `as any` suppression is gone.

#### 2.12 Removed Unused `@builder.io/vite-plugin-jsx-loc` Dev Dependency
Cleaned from `package.json`. This was a Manus platform build tool with no use outside that environment.

#### 2.13 Removed `AXIOS_TIMEOUT_MS` Constant
`shared/const.ts` no longer exports `AXIOS_TIMEOUT_MS` since axios is gone.

---

## 3. Remaining Recommendations (Not Auto-Applied)

These require your input or are architectural decisions:

1. **Shorten JWT session lifetime** — Currently 1 year. Consider reducing to 30 days and adding a silent token refresh mechanism.
2. **Replace Manus storage** — `server/storage.ts` calls the Manus Forge proxy. For local use, swap with local filesystem or MinIO (see Section 5).
3. **Implement local auth** — The app requires a Manus OAuth server to log in. For local testing, add the dev bypass in Section 4.
4. **Fix `siteTypes` column** — Currently stored as a JSON string in `text`. Consider a MySQL JSON column or a junction table for queryability.

---

## 4. Proxmox Setup — Docker Compose (Recommended)

### Prerequisites
- Proxmox LXC (Ubuntu 22.04+) or VM with Docker installed
- At least 2 CPU cores, 2 GB RAM, 10 GB disk

### Step 1: Install Docker

```bash
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker
docker --version
```

### Step 2: Copy Project Files

```bash
# From GitHub (once pushed):
git clone https://github.com/TheDarkRascal84/Camp-Intelligence.git /opt/camp-intelligence
cd /opt/camp-intelligence/camp-intelligence-proxmox

# Or from the ZIP:
unzip camp-intelligence-proxmox.zip -d /opt/camp-intelligence
cd /opt/camp-intelligence/camp-intelligence-proxmox
```

### Step 3: Configure Environment

```bash
cp .env.example .env
nano .env
```

Generate required secrets:
```bash
# JWT secret (paste into JWT_SECRET):
openssl rand -hex 32

# Redis password (paste into REDIS_PASSWORD):
openssl rand -hex 16

# MySQL passwords — choose your own strong passwords
```

### Step 4: Build and Start

```bash
docker compose up -d --build
```

Watch logs:
```bash
docker compose logs -f
```

Look for: `Server running on http://localhost:3000/`

### Step 5: Run Database Migrations (First Time Only)

```bash
docker compose exec app pnpm run db:push
```

### Step 6: Add Dev Auth Bypass (Required for Local Login)

Since the app requires Manus OAuth to log in, add this local bypass for development.

Open `server/_core/sdk.ts` and add at the very top of `authenticateRequest()`:

```typescript
async authenticateRequest(req: Request): Promise<User> {
  // LOCAL DEV BYPASS — remove before production use
  if (process.env.NODE_ENV !== 'production' && process.env.DEV_BYPASS_AUTH === 'true') {
    let user = await db.getUserByOpenId('dev-local-user');
    if (!user) {
      await db.upsertUser({
        openId: 'dev-local-user',
        name: 'Local Dev User',
        email: 'dev@localhost',
        loginMethod: 'local',
        lastSignedIn: new Date(),
        role: 'admin',
      });
      user = await db.getUserByOpenId('dev-local-user');
    }
    return user!;
  }
  // ... rest of existing method
```

Add to your `.env`:
```
DEV_BYPASS_AUTH=true
```

Rebuild:
```bash
docker compose up -d --build
```

### Step 7: Seed Demo Data

```bash
docker compose exec app pnpm tsx scripts/seed-demo-data.ts
```

### Step 8: Open the App

```
http://<your-proxmox-ip>:3000
```

### Step 9: Run Tests

```bash
docker compose exec app pnpm test
```

---

## 5. Optional: Local File Storage with MinIO

If your app uses `storagePut` / `storageGet`, run a local MinIO instance by adding this to `docker-compose.yml` services:

```yaml
minio:
  image: minio/minio
  container_name: camp-minio
  command: server /data --console-address ":9001"
  ports:
    - "9000:9000"
    - "9001:9001"
  environment:
    MINIO_ROOT_USER: ${MINIO_USER}
    MINIO_ROOT_PASSWORD: ${MINIO_PASSWORD}
  volumes:
    - minio_data:/data
  networks:
    - campnet
```

Then update `server/storage.ts` to use `@aws-sdk/client-s3` (already a dependency) pointing at `http://minio:9000`.

---

## 6. Files Changed in This Version

| File | Change |
|---|---|
| `server/_core/env.ts` | Hard-fail on missing/short JWT_SECRET and DATABASE_URL; added ALLOWED_ORIGINS, REDIS_PASSWORD env vars |
| `server/_core/index.ts` | Added Helmet, CORS, rate limiting; reduced body limit to 1MB; removed port scan loop; hard-fail on port conflict |
| `server/_core/sdk.ts` | Removed axios entirely; replaced with native fetch + AbortSignal timeout; fixed open redirect in decodeState |
| `server/routers.ts` | Fixed `as any` DB insert with typed `InsertSavedSearch`; cleaned up duplicate import |
| `shared/const.ts` | Removed unused `AXIOS_TIMEOUT_MS` |
| `docker-compose.yml` | Removed all hardcoded fallback secrets; added Redis password auth |
| `.env.example` | Added REDIS_PASSWORD, ALLOWED_ORIGINS; removed all default secret values |
| `package.json` | Added helmet, cors, express-rate-limit, @types/cors; removed axios, jsonwebtoken, @types/jsonwebtoken, @builder.io/vite-plugin-jsx-loc |
