export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  // LLM API configuration - set FORGE_API_URL to your LLM proxy or use OpenAI-compatible endpoint
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? process.env.LLM_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? process.env.OPENAI_API_KEY ?? "",
  // Optional: allowed origins for CORS (comma-separated list)
  allowedOrigins: process.env.ALLOWED_ORIGINS ?? "",
  // Optional: Redis password
  redisPassword: process.env.REDIS_PASSWORD ?? "",
};

// Hard-fail on missing critical config at startup
if (!ENV.cookieSecret || ENV.cookieSecret.length < 32) {
  console.error("[Config] FATAL: JWT_SECRET is not set or is too short (minimum 32 characters). Refusing to start.");
  process.exit(1);
}
if (!ENV.databaseUrl) {
  console.error("[Config] FATAL: DATABASE_URL is not set. Refusing to start.");
  process.exit(1);
}
