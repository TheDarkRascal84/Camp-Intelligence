import "dotenv/config";
import express from "express";
import { createServer } from "http";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { ENV } from "./env";

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Security headers
  app.use(
    helmet({
      // Allow Vite HMR in development
      contentSecurityPolicy: ENV.isProduction ? undefined : false,
    })
  );

  // CORS — restrict to configured origins in production
  const allowedOrigins = ENV.allowedOrigins
    ? ENV.allowedOrigins.split(",").map(o => o.trim())
    : ENV.isProduction
      ? []
      : ["http://localhost:3000", "http://localhost:5173"];

  app.use(
    cors({
      origin: allowedOrigins.length > 0 ? allowedOrigins : false,
      credentials: true,
    })
  );

  // Rate limiting — 200 requests per 15 minutes per IP across all /api routes
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests, please try again later." },
  });

  // Stricter rate limit for auth/OAuth routes
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many authentication attempts, please try again later." },
  });

  app.use("/api/", apiLimiter);
  app.use("/api/oauth/", authLimiter);

  // Body parsers — 1mb is sufficient for JSON payloads; raise only if file uploads are added
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ limit: "1mb", extended: true }));

  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  // Development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = parseInt(process.env.PORT || "3000");

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });

  server.on("error", (err: NodeJS.ErrnoException) => {
    if (err.code === "EADDRINUSE") {
      console.error(`[Server] FATAL: Port ${port} is already in use. Set a different PORT in your .env file.`);
    } else {
      console.error("[Server] FATAL: Failed to start server:", err.message);
    }
    process.exit(1);
  });
}

startServer().catch(console.error);
